import React from "react";
import ReviewForm from "../components/ReviewForm";

const SubmitReview = () => {
  return (
    <div>
      <h1>Submit Your Review</h1>
      <ReviewForm />
    </div>
  );
};

export default SubmitReview;

import { Routes, Route } from "react-router-dom";
import LandingPage from "./pages/LandingPage";
import SubmitReview from "./pages/SubmitReview";

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/submit-review" element={<SubmitReview />} />
    </Routes>
  );
};

export default App;
